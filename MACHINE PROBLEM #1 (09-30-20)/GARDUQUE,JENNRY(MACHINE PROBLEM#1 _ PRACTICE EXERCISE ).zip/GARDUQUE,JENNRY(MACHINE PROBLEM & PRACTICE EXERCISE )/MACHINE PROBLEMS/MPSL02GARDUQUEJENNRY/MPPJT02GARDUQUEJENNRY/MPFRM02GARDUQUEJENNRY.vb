﻿Public Class MPFRM02GARDUQUEJENNRY

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim prelim, midterm, final As Integer
        Dim total As Double
        prelim = TextBox1.Text
        midterm = TextBox2.Text
        final = TextBox3.Text

        total = prelim / 100 * 25 + midterm / 100 * 25 + final / 100 * 50
        TextBox4.Text = total

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()

    End Sub

End Class
