﻿Public Class MPFRM01GARDUQUEJENNRY

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim n1, n2, sum, minus, product As Integer
        Dim quotient, modulus, integerquo As Double

        n1 = TextBox1.Text
        n2 = TextBox2.Text

        sum = n1 + n2

        TextBox3.Text = sum
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim n1, n2, sum, minus, product As Integer
        Dim quotient, modulus, integerquo As Double

        n1 = TextBox1.Text
        n2 = TextBox2.Text

        minus = n1 - n2

        TextBox3.Text = minus
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim n1, n2, sum, minus, product As Integer
        Dim quotient, modulus, integerquo As Double

        n1 = TextBox1.Text
        n2 = TextBox2.Text

        product = n1 * n2

        TextBox3.Text = product
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim n1, n2, sum, minus, product As Integer
        Dim quotient, modulus, integerquo As Double

        n1 = TextBox1.Text
        n2 = TextBox2.Text

        quotient = n1 / n2

        TextBox3.Text = quotient
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim n1, n2, sum, minus, product As Integer
        Dim quotient, modulus, integerquo As Double

        n1 = TextBox1.Text
        n2 = TextBox2.Text

        modulus = n1 Mod n2

        TextBox3.Text = modulus
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim n1, n2, sum, minus, product As Integer
        Dim quotient, modulus, integerquo As Double

        n1 = TextBox1.Text
        n2 = TextBox2.Text

        integerquo = n1 \ n2

        TextBox3.Text = integerquo
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Close()
    End Sub
End Class
