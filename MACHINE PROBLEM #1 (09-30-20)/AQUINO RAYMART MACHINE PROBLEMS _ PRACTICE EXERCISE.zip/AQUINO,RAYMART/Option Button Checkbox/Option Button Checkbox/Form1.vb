﻿Public Class Form1

    Private Sub btnTRB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTRB.Click
        If rdoBSIT.Checked = True Then
            MessageBox.Show("Your course is: " + rdoBSIT.Text, "RadioButton")
        ElseIf rdoBSCS.Checked = True Then
            MessageBox.Show("Your course is: " + rdoBSCS.Text, "RadioButton")
        ElseIf rdoBSIS.Checked = True Then
            MessageBox.Show("Your course is: " + rdoBSIS.Text, "RadioButton")
        Else
            MessageBox.Show("No course selected...", "Radio Button")
        End If
    End Sub
    Private Sub btnTCB_Click(ByVal sender As System.Object, ByVal ByVale As System.EventArgs) Handles btnTCB.Click
        Dim Subj As String

        If ckCom.Checked Then
            Subj = Subj + ckCom.Text + vbNewLine
        End If
        If ckEng.Checked Then
            Subj = Subj + ckEng.Text + vbNewLine
        End If
        If ckFil.Checked Then
            Subj = Subj + ckFil.Text + vbNewLine
        End If
        If ckSci.Checked Then
            Subj = Subj + ckSci.Text + vbNewLine
        End If
        If ckMath.Checked Then
            Subj = Subj + ckMath.Text + vbNewLine
        End If

        MessageBox.Show("Your favorite subject/s is/are:" + vbNewLine + Subj, "Check Box")

    End Sub

    Private Sub btnCA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCA.Click
        rdoBSIT.Checked = False
        rdoBSCS.Checked = False
        rdoBSIS.Checked = False
        ckFil.Checked = False
        ckCom.Checked = False
        ckSci.Checked = False
        ckEng.Checked = False
        ckMath.Checked = False
    End Sub
End Class
