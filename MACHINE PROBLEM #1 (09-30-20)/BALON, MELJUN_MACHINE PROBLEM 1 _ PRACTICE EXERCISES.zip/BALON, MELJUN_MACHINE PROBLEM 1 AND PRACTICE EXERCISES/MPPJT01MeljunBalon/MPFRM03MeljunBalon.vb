﻿Public Class MPFRM03MeljunBalon

    Private Sub MPFRM03MeljunBalon_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim P, Q, ST, DA, NA As Integer
        P = TextBox1.Text
        Q = TextBox2.Text
        ST = P * Q
        TextBox3.Text = ST
        DA = ST * 0.2
        TextBox4.Text = DA
        NA = ST - DA
        TextBox5.Text = NA
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()
    End Sub
End Class