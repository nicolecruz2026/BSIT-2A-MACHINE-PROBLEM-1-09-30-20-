﻿Public Class MPFRM02MeljunBalon

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim G1, G2, G3, Grade As Double
        G1 = TextBox1.Text
        G2 = TextBox2.Text
        G3 = TextBox3.Text

        G1 = G1 * 0.25
        G2 = G2 * 0.25
        G3 = G3 * 0.5

        Grade = G1 + G2 + G3
        TextBox4.Text = Grade
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()
    End Sub
End Class