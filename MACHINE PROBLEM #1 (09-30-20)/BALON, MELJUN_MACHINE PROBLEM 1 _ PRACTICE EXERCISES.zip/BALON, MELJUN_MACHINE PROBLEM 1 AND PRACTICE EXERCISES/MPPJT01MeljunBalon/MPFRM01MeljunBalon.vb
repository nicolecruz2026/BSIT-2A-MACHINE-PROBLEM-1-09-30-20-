﻿Public Class MPFRM01MeljunBalon

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim N1, N2, Sum As Integer
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        Sum = N1 + N2
        TextBox3.Text = Sum

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim N1, N2, Difference As Integer
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        Difference = N1 - N2
        TextBox3.Text = Difference
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim N1, N2, Product As Integer
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        Product = N1 * N2
        TextBox3.Text = Product
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim N1, N2, Quotient As Integer
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        Quotient = N1 / N2
        TextBox3.Text = Quotient
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim N1, N2, Modulus As Integer
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        Modulus = N1 Mod N2
        TextBox3.Text = Modulus
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim N1, N2, ID As Integer
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        ID = N1 \ N2
        TextBox3.Text = ID
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Close()
    End Sub
End Class
