﻿Public Class MPFRM04MeljunBalon

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim B, P, Exponent As Integer
        B = TextBox1.Text
        P = TextBox2.Text
        Exponent = Math.Pow(B, P)
        TextBox3.Text = Exponent
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim R, A As Double
        R = TextBox4.Text
        A = (R * R) * 3.1416
        TextBox5.Text = A
        TextBox5.Text = Format(A, "#.##")

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim A, R, C As Double
        R = TextBox4.Text
        A = (R * R) * 3.1416
        TextBox5.Text = A
        TextBox5.Text = Format(A, "#.##")
        C = (3.1416 * R) * 2
        TextBox6.Text = C
        TextBox6.Text = Format(C, "#.##")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim R, A, C, D As Double
        R = TextBox4.Text
        A = (R * R) * 3.1416
        TextBox5.Text = A
        TextBox5.Text = Format(A, "#.##")
        C = (3.1416 * R) * 2
        TextBox6.Text = C
        TextBox6.Text = Format(C, "#.##")
        D = 2 * R
        TextBox7.Text = D
        TextBox7.Text = Format(D, "#.00")

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Close()
    End Sub
End Class