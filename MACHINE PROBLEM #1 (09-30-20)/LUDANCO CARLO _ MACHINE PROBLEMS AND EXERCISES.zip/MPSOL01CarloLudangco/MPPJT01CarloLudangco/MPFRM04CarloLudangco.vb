﻿Public Class MPFRM04CarloLudangco

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim base, power, total As Double
        base = TextBox1.Text
        power = TextBox2.Text

        total = base ^ power
        TextBox3.Text = total

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Close()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim π, Area, Radius As Double
        π = 3.1416
        Radius = TextBox4.Text
        Area = π * Radius ^ 2
        TextBox5.Text = Format(Area, "####.00")

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim π, circumference, Radius As Double
        π = 3.1416
        Radius = TextBox4.Text
        circumference = 2 * π * Radius
        TextBox6.Text = Format(circumference, "####.00")

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim diameter, Radius As Double
        Radius = TextBox4.Text
        diameter = 2 * Radius
        TextBox7.Text = Format(diameter, "####.00")

    End Sub
End Class