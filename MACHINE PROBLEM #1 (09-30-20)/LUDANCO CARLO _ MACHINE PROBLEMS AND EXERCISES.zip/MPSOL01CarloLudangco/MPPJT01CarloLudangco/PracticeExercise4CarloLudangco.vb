﻿Public Class PracticeExercise4CarloLudangco


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click
        If txtFinalGrade.Text >= 74.5 Then
            lblRemarks.Text = "Passed"
        Else
            lblRemarks.Text = "Failed"
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtFinalGrade.Text = ""
        lblRemarks.Text = ""

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Close()

    End Sub
End Class