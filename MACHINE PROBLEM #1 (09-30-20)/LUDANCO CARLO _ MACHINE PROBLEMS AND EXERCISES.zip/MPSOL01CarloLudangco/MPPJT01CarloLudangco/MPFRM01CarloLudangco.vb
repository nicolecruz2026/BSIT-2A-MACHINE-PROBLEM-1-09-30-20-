﻿Public Class MPFRM01CarloLudangco

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Close()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim argument1, argument2, sum As Integer


        argument1 = TextBox1.Text
        argument2 = TextBox2.Text

        sum = argument1 + argument2
        TextBox3.Text = sum

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim argument1, argument2, difference As Integer


        argument1 = TextBox1.Text
        argument2 = TextBox2.Text

        difference = argument1 - argument2
        TextBox3.Text = difference

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim argument1, argument2 As Integer
        Dim product As Integer

        argument1 = TextBox1.Text
        argument2 = TextBox2.Text

        product = argument1 * argument2
        TextBox3.Text = product

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim argument1, argument2 As Integer
        Dim quotient As Integer

        argument1 = TextBox1.Text
        argument2 = TextBox2.Text

        quotient = argument1 / argument2
        TextBox3.Text = quotient

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim argument1, argument2 As Integer
        Dim modulus As Integer

        argument1 = TextBox1.Text
        argument2 = TextBox2.Text

        modulus = argument1 Mod argument2
        TextBox3.Text = modulus

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim argument1, argument2 As Integer
        Dim integerdiv As Integer

        argument1 = TextBox1.Text
        argument2 = TextBox2.Text

        integerdiv = argument1 \ argument2
        TextBox3.Text = integerdiv

    End Sub
End Class
