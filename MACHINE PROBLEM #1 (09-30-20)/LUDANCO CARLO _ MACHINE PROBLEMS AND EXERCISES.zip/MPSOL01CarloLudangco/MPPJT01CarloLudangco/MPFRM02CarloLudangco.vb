﻿Public Class MPFRM02CarloLudangco

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim prelim, midterm, final, semgrade As Double
        prelim = TextBox1.Text
        midterm = TextBox2.Text
        final = TextBox3.Text

        semgrade = (((prelim + midterm) / 2) + final) / 2
        TextBox4.Text = semgrade

    End Sub

    Private Sub MPFRM02CarloLudangco_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class