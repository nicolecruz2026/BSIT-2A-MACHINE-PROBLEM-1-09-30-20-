﻿Public Class MPFRM06CarlNumos

    Private Sub btnTest_Click(sender As Object, e As EventArgs) Handles btnTest.Click
        If txtFinalGrade.Text >= 74.5 Then
            lblRemarks.Text = "Passed"
        Else
            lblRemarks.Text = "Failed"
        End If
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVale As System.EventArgs) Handles btnClear.Click
        txtFinalGrade.Text = ""
        lblRemarks.Text = ""
    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVale As System.EventArgs) Handles btnExit.Click
        Dim Response As Integer
        Response = MessageBox.Show("Close Program...", "Exit", _
        MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If Response = DialogResult.Yes Then
            Close()
        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub txtFinalGrade_TextChanged(sender As Object, e As EventArgs) Handles txtFinalGrade.TextChanged

    End Sub

    Private Sub lblRemarks_Click(sender As Object, e As EventArgs) Handles lblRemarks.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class