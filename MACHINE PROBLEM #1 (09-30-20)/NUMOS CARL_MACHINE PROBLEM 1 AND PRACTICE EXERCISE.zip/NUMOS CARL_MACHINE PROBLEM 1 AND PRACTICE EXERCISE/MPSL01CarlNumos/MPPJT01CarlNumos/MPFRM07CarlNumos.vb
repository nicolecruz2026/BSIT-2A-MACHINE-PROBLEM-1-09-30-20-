﻿Public Class MPFRM07CarlNumos

    Private Sub btnTestRdoBtn_Click(sender As Object, e As EventArgs) Handles btnTestRdoBtn.Click
        If rdoBSIT.Checked = True Then
            MessageBox.Show("Your course is: " + rdoBSIT.Text, "RadioButton")
        ElseIf rdoBSCS.Checked = True Then
            MessageBox.Show("Your course is: " + rdoBSCS.Text, "RadioButton")
        ElseIf rdoBSIS.Checked = True Then
            MessageBox.Show("Your course is: " + rdoBSIS.Text, "RadioButton")
        Else
            MessageBox.Show("No course selected...", "Radio Button")

        End If
    End Sub
    Private Sub btnTestChkBox_Click(ByVal sender As System.Object, ByVale As System.EventArgs) Handles btnTestChkBox.Click
        Dim Subj As String
        Subj = ("")
        If chkCom.Checked Then
            Subj = Subj + chkCom.Text + vbNewLine
        End If
        If chkEng.Checked Then
            Subj = Subj + chkEng.Text + vbNewLine
        End If
        If chkFil.Checked Then
            Subj = Subj + chkFil.Text + vbNewLine
        End If
        If chkSci.Checked Then
            Subj = Subj + chkSci.Text + vbNewLine
        End If
        If chkMat.Checked Then
            Subj = Subj + chkMat.Text + vbNewLine
        End If
        MessageBox.Show("Your favorite subject/s is/are:" + vbNewLine + Subj, "Check Box")
    End Sub
    Private Sub btnClearAll_Click(ByVal sender As System.Object, ByVale As System.EventArgs) Handles btnClearAll.Click
        'To clear radio buttons
        rdoBSIT.Checked = False
        rdoBSCS.Checked = False
        rdoBSIS.Checked = False
        'To clear check boxes
        chkFil.Checked = False
        chkCom.Checked = False
        chkSci.Checked = False
        chkEng.Checked = False
        chkMat.Checked = False
    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub
    Private Sub chkCom_CheckedChanged(sender As Object, e As EventArgs) Handles chkCom.CheckedChanged

    End Sub
    Private Sub chkEng_CheckedChanged(sender As Object, e As EventArgs) Handles chkEng.CheckedChanged

    End Sub
    Private Sub chkFil_CheckedChanged(sender As Object, e As EventArgs) Handles chkFil.CheckedChanged

    End Sub
    Private Sub chkSci_CheckedChanged(sender As Object, e As EventArgs) Handles chkSci.CheckedChanged

    End Sub
    Private Sub chkMat_CheckedChanged(sender As Object, e As EventArgs) Handles chkMat.CheckedChanged

    End Sub
    Private Sub rdoBSIT_CheckedChanged(sender As Object, e As EventArgs) Handles rdoBSIT.CheckedChanged

    End Sub
    Private Sub rdoBSCS_CheckedChanged(sender As Object, e As EventArgs) Handles rdoBSCS.CheckedChanged

    End Sub
    Private Sub rdoBSIS_CheckedChanged(sender As Object, e As EventArgs) Handles rdoBSIS.CheckedChanged

    End Sub
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class