﻿Public Class MPFRM01CarlNumos

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim N1, N2, ADD As Double
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        ADD = N1 + N2

        TextBox3.Text = ADD
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox1.Clear()

        TextBox2.Clear()

        TextBox3.Clear()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim N1, N2, SUBT As Double
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        SUBT = N1 - N2

        TextBox3.Text = SUBT
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim N1, N2, MUL As Double
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        MUL = N1 * N2

        TextBox3.Text = MUL
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim N1, N2, DIV As Double
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        DIV = N1 / N2

        TextBox3.Text = DIV
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim N1, N2, MODE As Double
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        MODE = N1 Mod N2

        TextBox3.Text = MODE
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim N1, N2, DIVINT As Double
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        DIVINT = N1 \ N2

        TextBox3.Text = DIVINT
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class
