﻿Public Class MPFRM03CarlNumos

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        TextBox5.Enabled = False
        Dim ProductAmount, Quantity, Mul, Dis, Min As Double
        ProductAmount = TextBox1.Text
        Quantity = TextBox2.Text
        Mul = (ProductAmount * Quantity)
        Dis = (Mul * 0.2)
        Min = (Mul - Dis)
        TextBox3.Text = Mul
        TextBox4.Text = Dis
        TextBox5.Text = Min
    End Sub
End Class