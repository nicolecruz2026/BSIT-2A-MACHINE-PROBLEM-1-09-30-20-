﻿Public Class MPFRM02CarlNumos

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox4.Enabled = False
        TextBox4.Text = ((TextBox1.Text * 0.25) + (TextBox2.Text * 0.25) + (TextBox3.Text * 0.5))
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Close()
    End Sub


End Class