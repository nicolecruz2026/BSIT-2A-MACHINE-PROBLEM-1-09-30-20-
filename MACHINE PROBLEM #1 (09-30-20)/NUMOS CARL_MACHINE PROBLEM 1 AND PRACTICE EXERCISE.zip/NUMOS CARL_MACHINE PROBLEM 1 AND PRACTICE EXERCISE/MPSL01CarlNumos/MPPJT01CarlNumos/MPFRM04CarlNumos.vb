﻿Public Class MPFRM04CarlNumos

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim N1, N2, Exp As Double
        N1 = TextBox1.Text
        N2 = TextBox2.Text
        Exp = N1 ^ N2

        TextBox3.Text = Exp
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Const π As Double = 3.1416
        Dim N1, Area As Double
        N1 = TextBox4.Text
        Area = π * TextBox4.Text ^ 2
        TextBox5.Text = Format(Area, ".00")
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Const π As Double = 3.1416
        Dim N1, Circumference As Double
        N1 = TextBox4.Text
        Circumference = 2 * π * TextBox4.Text
        TextBox6.Text = Format(Circumference, ".00")
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim N1, Diameter As Double
        N1 = TextBox4.Text
        Diameter = 2 * TextBox4.Text
        TextBox7.Text = Format(Diameter, ".00")
    End Sub
End Class