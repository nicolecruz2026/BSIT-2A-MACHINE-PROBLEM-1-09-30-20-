﻿Public Class MPFRM03EmmanuelleElimanco

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub txtProductAmount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtProductAmount.TextChanged

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Dim subTotal, productAmount, quantity As Double

        productAmount = txtProductAmount.Text
        quantity = txtQuantity.Text

        subTotal = productAmount * quantity
        txtSubTotal.Text = subTotal


        txtDiscountAmount.Text = subTotal * 0.2

        txtNetAmount.Text = subTotal - txtDiscountAmount.Text


    End Sub
End Class