﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM04EmmanuelleElimanco
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnDiameter = New System.Windows.Forms.Button()
        Me.btnCircum = New System.Windows.Forms.Button()
        Me.btnArea = New System.Windows.Forms.Button()
        Me.txtDiameter = New System.Windows.Forms.TextBox()
        Me.txtCircumference = New System.Windows.Forms.TextBox()
        Me.txtArea = New System.Windows.Forms.TextBox()
        Me.txtRadius = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnPower = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtBase = New System.Windows.Forms.TextBox()
        Me.txtEqual = New System.Windows.Forms.TextBox()
        Me.txtPower = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.MenuBar
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Location = New System.Drawing.Point(37, 18)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(66, 15)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = "  Exponent"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(37, 214)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(87, 31)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "Clear All"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(122, 214)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(87, 31)
        Me.Button2.TabIndex = 10
        Me.Button2.Text = "Exit"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btnDiameter
        '
        Me.btnDiameter.Location = New System.Drawing.Point(36, 159)
        Me.btnDiameter.Name = "btnDiameter"
        Me.btnDiameter.Size = New System.Drawing.Size(120, 22)
        Me.btnDiameter.TabIndex = 7
        Me.btnDiameter.Text = "Diameter"
        Me.btnDiameter.UseVisualStyleBackColor = True
        '
        'btnCircum
        '
        Me.btnCircum.Location = New System.Drawing.Point(36, 122)
        Me.btnCircum.Name = "btnCircum"
        Me.btnCircum.Size = New System.Drawing.Size(120, 22)
        Me.btnCircum.TabIndex = 6
        Me.btnCircum.Text = "Circumference"
        Me.btnCircum.UseVisualStyleBackColor = True
        '
        'btnArea
        '
        Me.btnArea.Location = New System.Drawing.Point(36, 83)
        Me.btnArea.Name = "btnArea"
        Me.btnArea.Size = New System.Drawing.Size(120, 22)
        Me.btnArea.TabIndex = 5
        Me.btnArea.Text = "Area"
        Me.btnArea.UseVisualStyleBackColor = True
        '
        'txtDiameter
        '
        Me.txtDiameter.Enabled = False
        Me.txtDiameter.Location = New System.Drawing.Point(162, 159)
        Me.txtDiameter.Name = "txtDiameter"
        Me.txtDiameter.Size = New System.Drawing.Size(81, 22)
        Me.txtDiameter.TabIndex = 8
        '
        'txtCircumference
        '
        Me.txtCircumference.Enabled = False
        Me.txtCircumference.Location = New System.Drawing.Point(162, 122)
        Me.txtCircumference.Name = "txtCircumference"
        Me.txtCircumference.Size = New System.Drawing.Size(81, 22)
        Me.txtCircumference.TabIndex = 7
        '
        'txtArea
        '
        Me.txtArea.Enabled = False
        Me.txtArea.Location = New System.Drawing.Point(162, 83)
        Me.txtArea.Name = "txtArea"
        Me.txtArea.Size = New System.Drawing.Size(81, 22)
        Me.txtArea.TabIndex = 6
        '
        'txtRadius
        '
        Me.txtRadius.Location = New System.Drawing.Point(116, 31)
        Me.txtRadius.Name = "txtRadius"
        Me.txtRadius.Size = New System.Drawing.Size(81, 22)
        Me.txtRadius.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(54, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 17)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Radius"
        '
        'btnPower
        '
        Me.btnPower.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPower.Location = New System.Drawing.Point(29, 130)
        Me.btnPower.Name = "btnPower"
        Me.btnPower.Size = New System.Drawing.Size(66, 34)
        Me.btnPower.TabIndex = 2
        Me.btnPower.Text = "="
        Me.btnPower.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(39, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Base"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(39, 93)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Power"
        '
        'txtBase
        '
        Me.txtBase.Location = New System.Drawing.Point(114, 41)
        Me.txtBase.Name = "txtBase"
        Me.txtBase.Size = New System.Drawing.Size(70, 22)
        Me.txtBase.TabIndex = 0
        '
        'txtEqual
        '
        Me.txtEqual.Enabled = False
        Me.txtEqual.Location = New System.Drawing.Point(114, 142)
        Me.txtEqual.Name = "txtEqual"
        Me.txtEqual.Size = New System.Drawing.Size(70, 22)
        Me.txtEqual.TabIndex = 5
        '
        'txtPower
        '
        Me.txtPower.Location = New System.Drawing.Point(114, 91)
        Me.txtPower.Name = "txtPower"
        Me.txtPower.Size = New System.Drawing.Size(70, 22)
        Me.txtPower.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtPower)
        Me.GroupBox1.Controls.Add(Me.txtBase)
        Me.GroupBox1.Controls.Add(Me.txtEqual)
        Me.GroupBox1.Controls.Add(Me.btnPower)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(216, 192)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Exponent"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnDiameter)
        Me.GroupBox2.Controls.Add(Me.btnArea)
        Me.GroupBox2.Controls.Add(Me.btnCircum)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.txtRadius)
        Me.GroupBox2.Controls.Add(Me.txtDiameter)
        Me.GroupBox2.Controls.Add(Me.txtArea)
        Me.GroupBox2.Controls.Add(Me.txtCircumference)
        Me.GroupBox2.Location = New System.Drawing.Point(253, 18)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(265, 216)
        Me.GroupBox2.TabIndex = 12
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Circle"
        '
        'MPFRM04EmmanuelleElimanco
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(534, 259)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "MPFRM04EmmanuelleElimanco"
        Me.Text = "Usage of Caret (^) Symbol"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents btnDiameter As System.Windows.Forms.Button
    Friend WithEvents btnCircum As System.Windows.Forms.Button
    Friend WithEvents btnArea As System.Windows.Forms.Button
    Friend WithEvents txtDiameter As System.Windows.Forms.TextBox
    Friend WithEvents txtCircumference As System.Windows.Forms.TextBox
    Friend WithEvents txtArea As System.Windows.Forms.TextBox
    Friend WithEvents txtRadius As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnPower As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtBase As System.Windows.Forms.TextBox
    Friend WithEvents txtEqual As System.Windows.Forms.TextBox
    Friend WithEvents txtPower As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
End Class
