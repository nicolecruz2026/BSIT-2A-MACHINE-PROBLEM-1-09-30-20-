﻿Public Class MPFRM01EmmanuelleElimanco

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim arg1, arg2 As Double

        arg1 = txtArg1.Text
        arg2 = txtArg2.Text
        txtResult.Text = arg1 + arg2
    End Sub

    Private Sub btnMinus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinus.Click
        Dim arg1, arg2 As Double

        arg1 = txtArg1.Text
        arg2 = txtArg2.Text
        txtResult.Text = arg1 - arg2
    End Sub

    Private Sub btnMultiply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMultiply.Click
        Dim arg1, arg2 As Double

        arg1 = txtArg1.Text
        arg2 = txtArg2.Text
        txtResult.Text = arg1 * arg2
    End Sub

    Private Sub btnFraction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFraction.Click
        Dim arg1, arg2 As Double

        arg1 = txtArg1.Text
        arg2 = txtArg2.Text
        txtResult.Text = arg1 / arg2
    End Sub

    Private Sub btnMOD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMOD.Click
        Dim arg1, arg2 As Double

        arg1 = txtArg1.Text
        arg2 = txtArg2.Text
        txtResult.Text = arg1 Mod arg2
    End Sub

    Private Sub btnDivide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDivide.Click
        Dim arg1, arg2 As Double

        arg1 = txtArg1.Text
        arg2 = txtArg2.Text
        txtResult.Text = arg1 \ arg2
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtArg1.Text = ""
        txtArg2.Text = ""
        txtResult.Text = ""

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        End
    End Sub
End Class
