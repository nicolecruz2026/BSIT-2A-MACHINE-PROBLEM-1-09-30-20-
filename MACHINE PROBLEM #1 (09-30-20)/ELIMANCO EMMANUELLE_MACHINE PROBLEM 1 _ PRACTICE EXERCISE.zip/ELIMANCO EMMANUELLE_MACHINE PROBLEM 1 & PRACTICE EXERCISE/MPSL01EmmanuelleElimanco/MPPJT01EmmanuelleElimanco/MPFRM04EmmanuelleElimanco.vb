﻿Public Class MPFRM04EmmanuelleElimanco
    Const π As Double = 3.1416
    Private Sub btnPower_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPower.Click

        Dim base, power As Double
        base = txtBase.Text
        power = txtPower.Text

        txtEqual.Text = base ^ power
    End Sub


    Private Sub btnArea_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnArea.Click


        Dim radius, result As Double


        radius = txtRadius.Text
        result = π * (radius ^ 2)
        txtArea.Text = Format(result, "#,###.00")

    End Sub

    Private Sub btnCircum_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCircum.Click

        Dim radius, result As Double

        radius = txtRadius.Text
        result = 2 * π * radius
        txtCircumference.Text = Format(result, "#,###.00")

    End Sub

    Private Sub btnDiameter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDiameter.Click

        Dim radius, result As Double

        radius = txtRadius.Text
        result = 2 * radius
        txtDiameter.Text = Format(result, "#,###.00")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        txtBase.Text = ""
        txtPower.Text = ""
        txtEqual.Text = ""
        txtRadius.Text = ""
        txtArea.Text = ""
        txtCircumference.Text = ""
        txtDiameter.Text = ""


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        End
    End Sub
End Class