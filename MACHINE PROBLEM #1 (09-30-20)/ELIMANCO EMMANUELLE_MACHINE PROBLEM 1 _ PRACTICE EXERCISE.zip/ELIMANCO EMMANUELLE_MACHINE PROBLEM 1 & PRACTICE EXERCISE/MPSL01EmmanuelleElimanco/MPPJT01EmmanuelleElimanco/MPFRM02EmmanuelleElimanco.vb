﻿Public Class MPFRM02EmmanuelleElimanco

    Private Sub btnCompute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompute.Click
        Dim prelim, midterm, final, semestralGrade As Double

        prelim = txtPrelim.Text * 0.25
        midterm = txtMidterm.Text * 0.25
        final = txtFinal.Text * 0.5

        semestralGrade = prelim + midterm + final
        txtSemestralGrade.Text = semestralGrade


    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtPrelim.Text = ""
        txtMidterm.Text = ""
        txtFinal.Text = ""
        txtSemestralGrade.Text = ""

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        End
    End Sub
End Class