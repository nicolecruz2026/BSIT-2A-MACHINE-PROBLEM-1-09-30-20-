﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OptionButtonAndCheckBox
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdoBSIS = New System.Windows.Forms.RadioButton()
        Me.rdoBSCS = New System.Windows.Forms.RadioButton()
        Me.rdoBSIT = New System.Windows.Forms.RadioButton()
        Me.btnTestRdoBtn = New System.Windows.Forms.Button()
        Me.btnTestChkBox = New System.Windows.Forms.Button()
        Me.btnClearAll = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkCom = New System.Windows.Forms.CheckBox()
        Me.chkEng = New System.Windows.Forms.CheckBox()
        Me.chkFil = New System.Windows.Forms.CheckBox()
        Me.chkSci = New System.Windows.Forms.CheckBox()
        Me.chkMat = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdoBSIS)
        Me.GroupBox1.Controls.Add(Me.rdoBSCS)
        Me.GroupBox1.Controls.Add(Me.rdoBSIT)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 21)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(199, 212)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Course"
        '
        'rdoBSIS
        '
        Me.rdoBSIS.AutoSize = True
        Me.rdoBSIS.Location = New System.Drawing.Point(21, 148)
        Me.rdoBSIS.Name = "rdoBSIS"
        Me.rdoBSIS.Size = New System.Drawing.Size(72, 24)
        Me.rdoBSIS.TabIndex = 3
        Me.rdoBSIS.TabStop = True
        Me.rdoBSIS.Text = "BSIS"
        Me.rdoBSIS.UseVisualStyleBackColor = True
        '
        'rdoBSCS
        '
        Me.rdoBSCS.AutoSize = True
        Me.rdoBSCS.Location = New System.Drawing.Point(21, 90)
        Me.rdoBSCS.Name = "rdoBSCS"
        Me.rdoBSCS.Size = New System.Drawing.Size(78, 24)
        Me.rdoBSCS.TabIndex = 2
        Me.rdoBSCS.TabStop = True
        Me.rdoBSCS.Text = "BSCS"
        Me.rdoBSCS.UseVisualStyleBackColor = True
        '
        'rdoBSIT
        '
        Me.rdoBSIT.AutoSize = True
        Me.rdoBSIT.Location = New System.Drawing.Point(21, 38)
        Me.rdoBSIT.Name = "rdoBSIT"
        Me.rdoBSIT.Size = New System.Drawing.Size(70, 24)
        Me.rdoBSIT.TabIndex = 1
        Me.rdoBSIT.TabStop = True
        Me.rdoBSIT.Text = "BSIT"
        Me.rdoBSIT.UseVisualStyleBackColor = True
        '
        'btnTestRdoBtn
        '
        Me.btnTestRdoBtn.Location = New System.Drawing.Point(12, 239)
        Me.btnTestRdoBtn.Name = "btnTestRdoBtn"
        Me.btnTestRdoBtn.Size = New System.Drawing.Size(199, 59)
        Me.btnTestRdoBtn.TabIndex = 1
        Me.btnTestRdoBtn.Text = "TestRadioButton"
        Me.btnTestRdoBtn.UseVisualStyleBackColor = True
        '
        'btnTestChkBox
        '
        Me.btnTestChkBox.Location = New System.Drawing.Point(227, 239)
        Me.btnTestChkBox.Name = "btnTestChkBox"
        Me.btnTestChkBox.Size = New System.Drawing.Size(199, 59)
        Me.btnTestChkBox.TabIndex = 3
        Me.btnTestChkBox.Text = "TestCheckBox"
        Me.btnTestChkBox.UseVisualStyleBackColor = True
        '
        'btnClearAll
        '
        Me.btnClearAll.Location = New System.Drawing.Point(432, 239)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(199, 59)
        Me.btnClearAll.TabIndex = 4
        Me.btnClearAll.Text = "Clear All"
        Me.btnClearAll.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkMat)
        Me.GroupBox2.Controls.Add(Me.chkSci)
        Me.GroupBox2.Controls.Add(Me.chkFil)
        Me.GroupBox2.Controls.Add(Me.chkEng)
        Me.GroupBox2.Controls.Add(Me.chkCom)
        Me.GroupBox2.Location = New System.Drawing.Point(227, 21)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(404, 212)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Favorite Subject/s"
        '
        'chkCom
        '
        Me.chkCom.AutoSize = True
        Me.chkCom.Location = New System.Drawing.Point(41, 38)
        Me.chkCom.Name = "chkCom"
        Me.chkCom.Size = New System.Drawing.Size(105, 24)
        Me.chkCom.TabIndex = 0
        Me.chkCom.Text = "Computer"
        Me.chkCom.UseVisualStyleBackColor = True
        '
        'chkEng
        '
        Me.chkEng.AutoSize = True
        Me.chkEng.Location = New System.Drawing.Point(41, 90)
        Me.chkEng.Name = "chkEng"
        Me.chkEng.Size = New System.Drawing.Size(87, 24)
        Me.chkEng.TabIndex = 1
        Me.chkEng.Text = "English"
        Me.chkEng.UseVisualStyleBackColor = True
        '
        'chkFil
        '
        Me.chkFil.AutoSize = True
        Me.chkFil.Location = New System.Drawing.Point(41, 148)
        Me.chkFil.Name = "chkFil"
        Me.chkFil.Size = New System.Drawing.Size(84, 24)
        Me.chkFil.TabIndex = 2
        Me.chkFil.Text = "Filipino"
        Me.chkFil.UseVisualStyleBackColor = True
        '
        'chkSci
        '
        Me.chkSci.AutoSize = True
        Me.chkSci.Location = New System.Drawing.Point(221, 38)
        Me.chkSci.Name = "chkSci"
        Me.chkSci.Size = New System.Drawing.Size(92, 24)
        Me.chkSci.TabIndex = 3
        Me.chkSci.Text = "Science"
        Me.chkSci.UseVisualStyleBackColor = True
        '
        'chkMat
        '
        Me.chkMat.AutoSize = True
        Me.chkMat.Location = New System.Drawing.Point(221, 90)
        Me.chkMat.Name = "chkMat"
        Me.chkMat.Size = New System.Drawing.Size(71, 24)
        Me.chkMat.TabIndex = 4
        Me.chkMat.Text = "Math"
        Me.chkMat.UseVisualStyleBackColor = True
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(644, 310)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.btnTestChkBox)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnTestRdoBtn)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form5"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoBSIS As System.Windows.Forms.RadioButton
    Friend WithEvents rdoBSCS As System.Windows.Forms.RadioButton
    Friend WithEvents rdoBSIT As System.Windows.Forms.RadioButton
    Friend WithEvents btnTestRdoBtn As System.Windows.Forms.Button
    Friend WithEvents btnTestChkBox As System.Windows.Forms.Button
    Friend WithEvents btnClearAll As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents chkMat As System.Windows.Forms.CheckBox
    Friend WithEvents chkSci As System.Windows.Forms.CheckBox
    Friend WithEvents chkFil As System.Windows.Forms.CheckBox
    Friend WithEvents chkEng As System.Windows.Forms.CheckBox
    Friend WithEvents chkCom As System.Windows.Forms.CheckBox
End Class
