﻿Public Class MPFRM04BlessieNaigal

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim base, power, equals As Integer

        base = TextBox1.Text
        power = TextBox2.Text

        equals = base ^ power
        TextBox3.Text = equals
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim radius, area, pi As Double

        pi = 3.1416
        radius = TextBox4.Text

        area = pi * radius * radius
        TextBox5.Text = area
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim radius, circum, pi As Double

        pi = 3.1416
        radius = TextBox4.Text

        circum = 2 * 3.1416
        TextBox6.Text = circum
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim radius, diameter, pi, circum As Double

        pi = 3.1416
        radius = TextBox4.Text

        diameter = circum / 3.1416
        TextBox7.Text = diameter
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Close()
    End Sub
End Class