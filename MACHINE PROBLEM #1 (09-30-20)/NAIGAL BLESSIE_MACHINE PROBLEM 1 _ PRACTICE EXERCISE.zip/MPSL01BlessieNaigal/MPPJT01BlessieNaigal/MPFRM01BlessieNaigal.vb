﻿Public Class MPFRM01BlessieNaigal


    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim N1, N2, Result As Integer

        N1 = TextBox1.Text
        N2 = TextBox2.Text

        Result = N1 + N2

        TextBox3.Text = Result

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim N1, N2, Result As Integer

        N1 = TextBox1.Text
        N2 = TextBox2.Text

        Result = N1 - N2

        TextBox3.Text = Result
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim N1, N2, Result As Integer

        N1 = TextBox1.Text
        N2 = TextBox2.Text

        Result = N1 * N2

        TextBox3.Text = Result
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim N1, N2, Result As Integer

        N1 = TextBox1.Text
        N2 = TextBox2.Text

        Result = N1 / N2

        TextBox3.Text = Result
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim N1, N2, Result As Integer

        N1 = TextBox1.Text
        N2 = TextBox2.Text

        Result = N1 Mod N2

        TextBox3.Text = Result
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim N1, N2, Result As Integer

        N1 = TextBox1.Text
        N2 = TextBox2.Text

        Result = N1 \ N2

        TextBox3.Text = Result
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Close()
    End Sub
End Class
