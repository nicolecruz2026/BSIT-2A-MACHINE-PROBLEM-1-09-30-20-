﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM04AnnaCamilleZamudio
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.resBox = New System.Windows.Forms.TextBox()
        Me.btnEquals = New System.Windows.Forms.Button()
        Me.powerBox = New System.Windows.Forms.TextBox()
        Me.baseBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnClearAll = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.diamBox = New System.Windows.Forms.TextBox()
        Me.circumBox = New System.Windows.Forms.TextBox()
        Me.btnDiam = New System.Windows.Forms.Button()
        Me.btnCircum = New System.Windows.Forms.Button()
        Me.areaBox = New System.Windows.Forms.TextBox()
        Me.btnArea = New System.Windows.Forms.Button()
        Me.radiusBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.resBox)
        Me.GroupBox1.Controls.Add(Me.btnEquals)
        Me.GroupBox1.Controls.Add(Me.powerBox)
        Me.GroupBox1.Controls.Add(Me.baseBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(139, 130)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Exponent"
        '
        'resBox
        '
        Me.resBox.Location = New System.Drawing.Point(70, 95)
        Me.resBox.Name = "resBox"
        Me.resBox.Size = New System.Drawing.Size(52, 20)
        Me.resBox.TabIndex = 5
        '
        'btnEquals
        '
        Me.btnEquals.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEquals.Location = New System.Drawing.Point(21, 92)
        Me.btnEquals.Name = "btnEquals"
        Me.btnEquals.Size = New System.Drawing.Size(43, 23)
        Me.btnEquals.TabIndex = 4
        Me.btnEquals.Text = "="
        Me.btnEquals.UseVisualStyleBackColor = True
        '
        'powerBox
        '
        Me.powerBox.Location = New System.Drawing.Point(80, 62)
        Me.powerBox.Name = "powerBox"
        Me.powerBox.Size = New System.Drawing.Size(42, 20)
        Me.powerBox.TabIndex = 3
        '
        'baseBox
        '
        Me.baseBox.Location = New System.Drawing.Point(80, 28)
        Me.baseBox.Name = "baseBox"
        Me.baseBox.Size = New System.Drawing.Size(42, 20)
        Me.baseBox.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Power"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(31, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Base"
        '
        'btnClearAll
        '
        Me.btnClearAll.Location = New System.Drawing.Point(12, 148)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(69, 23)
        Me.btnClearAll.TabIndex = 1
        Me.btnClearAll.Text = "Clear All"
        Me.btnClearAll.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(82, 148)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(69, 23)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.diamBox)
        Me.GroupBox2.Controls.Add(Me.circumBox)
        Me.GroupBox2.Controls.Add(Me.btnDiam)
        Me.GroupBox2.Controls.Add(Me.btnCircum)
        Me.GroupBox2.Controls.Add(Me.areaBox)
        Me.GroupBox2.Controls.Add(Me.btnArea)
        Me.GroupBox2.Controls.Add(Me.radiusBox)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Location = New System.Drawing.Point(167, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(201, 159)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Circle"
        '
        'diamBox
        '
        Me.diamBox.Location = New System.Drawing.Point(111, 123)
        Me.diamBox.Name = "diamBox"
        Me.diamBox.Size = New System.Drawing.Size(70, 20)
        Me.diamBox.TabIndex = 7
        '
        'circumBox
        '
        Me.circumBox.Location = New System.Drawing.Point(112, 95)
        Me.circumBox.Name = "circumBox"
        Me.circumBox.Size = New System.Drawing.Size(70, 20)
        Me.circumBox.TabIndex = 6
        '
        'btnDiam
        '
        Me.btnDiam.Location = New System.Drawing.Point(20, 121)
        Me.btnDiam.Name = "btnDiam"
        Me.btnDiam.Size = New System.Drawing.Size(85, 23)
        Me.btnDiam.TabIndex = 5
        Me.btnDiam.Text = "Diameter"
        Me.btnDiam.UseVisualStyleBackColor = True
        '
        'btnCircum
        '
        Me.btnCircum.Location = New System.Drawing.Point(20, 92)
        Me.btnCircum.Name = "btnCircum"
        Me.btnCircum.Size = New System.Drawing.Size(85, 23)
        Me.btnCircum.TabIndex = 4
        Me.btnCircum.Text = "Circumference"
        Me.btnCircum.UseVisualStyleBackColor = True
        '
        'areaBox
        '
        Me.areaBox.Location = New System.Drawing.Point(112, 65)
        Me.areaBox.Name = "areaBox"
        Me.areaBox.Size = New System.Drawing.Size(70, 20)
        Me.areaBox.TabIndex = 3
        '
        'btnArea
        '
        Me.btnArea.Location = New System.Drawing.Point(20, 65)
        Me.btnArea.Name = "btnArea"
        Me.btnArea.Size = New System.Drawing.Size(85, 23)
        Me.btnArea.TabIndex = 2
        Me.btnArea.Text = "Area"
        Me.btnArea.UseVisualStyleBackColor = True
        '
        'radiusBox
        '
        Me.radiusBox.Location = New System.Drawing.Point(95, 28)
        Me.radiusBox.Name = "radiusBox"
        Me.radiusBox.Size = New System.Drawing.Size(55, 20)
        Me.radiusBox.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 35)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Radius"
        '
        'MPFRM04AnnaCamilleZamudio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(380, 185)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "MPFRM04AnnaCamilleZamudio"
        Me.Text = "Usage of Caret (^) Symbol"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents resBox As System.Windows.Forms.TextBox
    Friend WithEvents btnEquals As System.Windows.Forms.Button
    Friend WithEvents powerBox As System.Windows.Forms.TextBox
    Friend WithEvents baseBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnClearAll As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents radiusBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnCircum As System.Windows.Forms.Button
    Friend WithEvents areaBox As System.Windows.Forms.TextBox
    Friend WithEvents btnArea As System.Windows.Forms.Button
    Friend WithEvents diamBox As System.Windows.Forms.TextBox
    Friend WithEvents circumBox As System.Windows.Forms.TextBox
    Friend WithEvents btnDiam As System.Windows.Forms.Button
End Class
