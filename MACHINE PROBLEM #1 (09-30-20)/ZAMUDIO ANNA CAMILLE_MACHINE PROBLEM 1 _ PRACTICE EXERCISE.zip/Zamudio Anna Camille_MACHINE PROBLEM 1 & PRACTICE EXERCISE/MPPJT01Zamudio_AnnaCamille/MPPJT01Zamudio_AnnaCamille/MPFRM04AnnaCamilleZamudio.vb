﻿Public Class MPFRM04AnnaCamilleZamudio

    Private Sub btnEquals_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEquals.Click
        Dim base, power, res As Double

        base = baseBox.Text
        power = powerBox.Text

        res = base ^ power

        resBox.Text = res
    End Sub

    Private Sub btnClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click
        baseBox.Clear()
        powerBox.Clear()
        resBox.Clear()
        radiusBox.Clear()
        areaBox.Clear()
        circumBox.Clear()
        diamBox.Clear()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnArea_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnArea.Click
        Dim radius, area As Double
        Const pi As Double = 3.1416

        radius = radiusBox.Text

        area = radius ^ 2 * pi

        areaBox.Text = Format(area, "#.##")
    End Sub

    Private Sub btnCircum_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCircum.Click
        Dim radius, circum As Double
        Const pi As Double = 3.1416

        radius = radiusBox.Text

        circum = 2 * pi * radius

        circumBox.Text = Format(circum, "#.##")
    End Sub

    Private Sub btnDiam_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDiam.Click
        Dim radius, diam As Double

        radius = radiusBox.Text

        diam = 2 * radius

        diamBox.Text = Format(diam, "#.##")
    End Sub
End Class