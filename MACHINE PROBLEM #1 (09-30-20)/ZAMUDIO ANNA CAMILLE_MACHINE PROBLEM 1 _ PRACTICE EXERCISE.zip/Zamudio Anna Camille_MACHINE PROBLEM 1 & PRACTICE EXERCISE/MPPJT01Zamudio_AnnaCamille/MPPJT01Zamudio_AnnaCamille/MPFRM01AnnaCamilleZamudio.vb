﻿Public Class MPFRM01AnnaCamilleZamudio

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Arg1Box_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Arg1Box.TextChanged

    End Sub

    Private Sub Arg2Box_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Arg2Box.TextChanged

    End Sub

    Private Sub ResBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResBox.TextChanged

    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim num1, num2, resAdd As Double

        num1 = Arg1Box.Text
        num2 = Arg2Box.Text

        resAdd = num1 + num2

        ResBox.Text = resAdd
    End Sub

    Private Sub btnSub_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSub.Click
        Dim num1, num2, resSub As Double

        num1 = Arg1Box.Text
        num2 = Arg2Box.Text

        resSub = num1 - num2

        ResBox.Text = resSub
    End Sub

    Private Sub btnMulti_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMulti.Click
        Dim num1, num2, resMulti As Double

        num1 = Arg1Box.Text
        num2 = Arg2Box.Text

        resMulti = num1 * num2

        ResBox.Text = resMulti
    End Sub

    Private Sub btnDiv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDiv.Click
        Dim num1, num2, resDiv As Double

        num1 = Arg1Box.Text
        num2 = Arg2Box.Text

        resDiv = num1 / num2

        ResBox.Text = resDiv
    End Sub

    Private Sub btnMod_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMod.Click
        Dim num1, num2, resMod As Double

        num1 = Arg1Box.Text
        num2 = Arg2Box.Text

        resMod = num1 Mod num2

        ResBox.Text = resMod
    End Sub

    Private Sub btnIntDiv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIntDiv.Click
        Dim num1, num2, resIntdiv As Integer

        num1 = Arg1Box.Text
        num2 = Arg2Box.Text

        resIntdiv = num1 \ num2

        ResBox.Text = resIntdiv
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Arg1Box.Clear()
        Arg2Box.Clear()
        ResBox.Clear()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Close()
    End Sub
End Class
