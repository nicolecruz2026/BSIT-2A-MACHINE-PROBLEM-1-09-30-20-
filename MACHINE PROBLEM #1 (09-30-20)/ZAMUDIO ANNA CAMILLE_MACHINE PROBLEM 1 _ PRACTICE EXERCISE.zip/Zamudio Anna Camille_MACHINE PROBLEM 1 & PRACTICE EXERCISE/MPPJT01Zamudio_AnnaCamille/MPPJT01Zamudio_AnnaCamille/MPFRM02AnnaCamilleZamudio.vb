﻿Public Class MPFRM02AnnaCamilleZamudio

    Private Sub MPFRM02AnnaCamilleZamudio_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub addPrelim_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addPrelim.TextChanged

    End Sub

    Private Sub addMid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addMid.TextChanged

    End Sub

    Private Sub addFinal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addFinal.TextChanged

    End Sub

    Private Sub resBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles resBox.TextChanged

    End Sub

    Private Sub btnComp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnComp.Click
        Dim pre, pre1, midterm, midterm1, fin, fin1, semGrade As Double

        pre = addPrelim.Text
        midterm = addMid.Text
        fin = addFinal.Text

        pre1 = 0.25 * pre
        midterm1 = 0.25 * midterm
        fin1 = 0.5 * fin
        semGrade = pre1 + midterm1 + fin1

        resBox.Text = semGrade
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        addPrelim.Clear()
        addMid.Clear()
        addFinal.Clear()
        resBox.Clear()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Close()
    End Sub
End Class