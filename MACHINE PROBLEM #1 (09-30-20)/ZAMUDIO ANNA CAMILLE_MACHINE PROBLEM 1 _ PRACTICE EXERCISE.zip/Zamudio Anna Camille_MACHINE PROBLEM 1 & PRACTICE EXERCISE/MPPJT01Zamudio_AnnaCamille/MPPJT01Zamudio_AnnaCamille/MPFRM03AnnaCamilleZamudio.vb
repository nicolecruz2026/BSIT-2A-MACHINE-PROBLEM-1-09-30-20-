﻿Public Class MPFRM03AnnaCamilleZamudio

    Private Sub ProdBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProdBox.TextChanged

    End Sub

    Private Sub QuanBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QuanBox.TextChanged

    End Sub

    Private Sub SubTotalBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubTotalBox.TextChanged

    End Sub

    Private Sub DiscBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DiscBox.TextChanged

    End Sub

    Private Sub NetBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NetBox.TextChanged

    End Sub

    Private Sub btnCalc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalc.Click
        Dim pro, quan, subtotal, disc, net As Double

        pro = ProdBox.Text
        quan = QuanBox.Text

        subtotal = pro * quan
        disc = 0.2 * subtotal
        net = subtotal - disc

        SubTotalBox.Text = subtotal
        DiscBox.Text = disc
        NetBox.Text = net
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ProdBox.Clear()
        QuanBox.Clear()
        SubTotalBox.Clear()
        DiscBox.Clear()
        NetBox.Clear()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Close()
    End Sub

End Class
