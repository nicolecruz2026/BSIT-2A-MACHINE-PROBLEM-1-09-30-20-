﻿Public Class PREXER04AnnaCamilleZamudio

    Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click
        If txtFinalGrade.Text >= 74.5 Then
            lblRemarks.Text = "Passed"
        Else
            lblRemarks.Text = "Failed"
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtFinalGrade.Text = ""
        txtFinalGrade.Focus()
        lblRemarks.Text = ""
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Dim Response As Integer
        Response = MessageBox.Show("Close Program...", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If Response = DialogResult.Yes Then
            Close()
        End If
    End Sub
End Class