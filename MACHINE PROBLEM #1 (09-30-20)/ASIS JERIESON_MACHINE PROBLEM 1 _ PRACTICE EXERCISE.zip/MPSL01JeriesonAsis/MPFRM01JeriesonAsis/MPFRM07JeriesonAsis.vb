﻿Public Class MPFRM07JeriesonAsis

   
    Private Sub btnTestRdoBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestRdoBtn.Click

        If rdoBSIT.Checked = True Then
            MessageBox.Show("Your Course is:" + rdoBSIT.Text, "Radio Button")
        ElseIf rdoBSCS.Checked = True Then
            MessageBox.Show("Your Course is:" + rdoBSCS.Text, "Radio Button")
        ElseIf rdoBSIS.Checked = True Then
            MessageBox.Show("Your Course is:" + rdoBSIS.Text, "Radio Button")
        Else
            MessageBox.Show("No Course selected...", "RadioButton")
        End If

    End Sub

    Private Sub btnTestChkBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestChkBox.Click

        Dim subject As String
        subject = ""
        If chkCom.Checked Then
            subject = subject + chkCom.Text + vbNewLine
        End If
        If chkEng.Checked Then
            subject = subject + chkEng.Text + vbNewLine
        End If
        If chkFil.Checked Then
            subject = subject + chkFil.Text + vbNewLine
        End If
        If chkSci.Checked Then
            subject = subject + chkSci.Text + vbNewLine
        End If
        If chkMat.Checked Then
            subject = subject + chkMat.Text + vbNewLine
        End If
        MessageBox.Show("Yourfavorite subject/s is/are:" + vbNewLine + subject, "Check Box")

    End Sub

    Private Sub btnClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click

        rdoBSIT.Checked = False
        rdoBSCS.Checked = False
        rdoBSIS.Checked = False
        chkCom.Checked = False
        chkEng.Checked = False
        chkFil.Checked = False
        chkMat.Checked = False
        chkSci.Checked = False

    End Sub
End Class