﻿Public Class MPFRM01JeriesonAsis


    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        Dim num1, num2, SUM As Integer

        num1 = TextBox1.Text
        num2 = TextBox2.Text
        SUM = num1 + num2
        TextBox3.Text = SUM

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        Dim num1, num2, DIFFERENCE As Integer

        num1 = TextBox1.Text
        num2 = TextBox2.Text
        DIFFERENCE = num1 - num2
        TextBox3.Text = DIFFERENCE

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        Dim num1, num2, PRODUCT As Integer

        num1 = TextBox1.Text
        num2 = TextBox2.Text
        PRODUCT = num1 * num2
        TextBox3.Text = PRODUCT

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click

        Dim num1, num2, QUOTIENT As Integer

        num1 = TextBox1.Text
        num2 = TextBox2.Text
        QUOTIENT = num1 / num2
        TextBox3.Text = QUOTIENT

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click

        Dim num1, num2, MODULO As Integer

        num1 = TextBox1.Text
        num2 = TextBox2.Text
        MODULO = num1 Mod num2
        TextBox3.Text = MODULO

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click

        Dim num1, num2, INTEGERDIV As Integer

        num1 = TextBox1.Text
        num2 = TextBox2.Text
        INTEGERDIV = num1 \ num2
        TextBox3.Text = INTEGERDIV

    End Sub

    Private Sub MPFRM01JeriesonAsis_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Close()

    End Sub
End Class
