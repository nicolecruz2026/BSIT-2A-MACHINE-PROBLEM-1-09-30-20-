﻿
Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

End Sub
Public Class MPFRM006PaulineTumala

    Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click
        If txtFinalGrade.Text >= 74.5 Then
            lblRemarks.Text = "Passed"
        Else
            lblRemarks.Text = "Failed"
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtFinalGrade.Text = ""
        lblRemarks.Text = ""
    End Sub
End Class