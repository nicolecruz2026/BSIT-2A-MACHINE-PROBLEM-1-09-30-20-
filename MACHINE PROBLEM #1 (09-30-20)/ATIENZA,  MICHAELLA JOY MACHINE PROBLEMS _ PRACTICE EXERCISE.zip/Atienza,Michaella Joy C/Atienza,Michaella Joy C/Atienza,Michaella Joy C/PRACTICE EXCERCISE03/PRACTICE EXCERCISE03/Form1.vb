﻿Public Class frmDateTime

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = Today.DayOfWeek.ToString
        Label2.Text = TimeOfDay
        Label3.Text = Today.ToString("MMMM") 'Label4.Text
        Label4.Text = Today.ToString("dd")
        Label5.Text = Today.Year
    End Sub

End Class
