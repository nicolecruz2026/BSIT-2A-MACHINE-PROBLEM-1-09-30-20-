﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim prd, qnty As Integer

        prd = TextBox1.Text
        qnty = TextBox2.Text
        

        TextBox3.Text = prd * qnty
        TextBox4.Text = (TextBox3.Text * 0.2)
        TextBox5.Text = TextBox3.Text - TextBox4.Text




    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""


    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()
    End Sub

End Class
