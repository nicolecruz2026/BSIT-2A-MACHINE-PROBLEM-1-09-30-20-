﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim t1, t2, result As Double

        t1 = TextBox1.Text
        t2 = TextBox2.Text

        result = t1 ^ t2
        TextBox3.Text = result
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim rad, results As Double
        rad = TextBox4.Text


        results = 3.1416 * rad * rad
        TextBox5.Text = results

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim rad, resultss As Double

        rad = TextBox4.Text
        resultss = 2 * 3.1416 * rad
        TextBox6.Text = resultss

    End Sub

    
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim rad, resultsss As Double

        rad = TextBox4.Text
        resultsss = 2 * rad
        TextBox7.Text = resultsss

    End Sub
End Class
