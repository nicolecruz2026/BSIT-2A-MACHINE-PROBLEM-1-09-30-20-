﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdoBSIS = New System.Windows.Forms.RadioButton()
        Me.rdoBSCS = New System.Windows.Forms.RadioButton()
        Me.rdoBSIT = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ckMath = New System.Windows.Forms.CheckBox()
        Me.ckSci = New System.Windows.Forms.CheckBox()
        Me.ckFil = New System.Windows.Forms.CheckBox()
        Me.ckEng = New System.Windows.Forms.CheckBox()
        Me.ckCom = New System.Windows.Forms.CheckBox()
        Me.btnTRB = New System.Windows.Forms.Button()
        Me.btnTCB = New System.Windows.Forms.Button()
        Me.btnCA = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdoBSIS)
        Me.GroupBox1.Controls.Add(Me.rdoBSCS)
        Me.GroupBox1.Controls.Add(Me.rdoBSIT)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 38)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(143, 219)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Course"
        '
        'rdoBSIS
        '
        Me.rdoBSIS.AutoSize = True
        Me.rdoBSIS.Location = New System.Drawing.Point(7, 161)
        Me.rdoBSIS.Name = "rdoBSIS"
        Me.rdoBSIS.Size = New System.Drawing.Size(49, 17)
        Me.rdoBSIS.TabIndex = 2
        Me.rdoBSIS.TabStop = True
        Me.rdoBSIS.Text = "BSIS"
        Me.rdoBSIS.UseVisualStyleBackColor = True
        '
        'rdoBSCS
        '
        Me.rdoBSCS.AutoSize = True
        Me.rdoBSCS.Location = New System.Drawing.Point(7, 105)
        Me.rdoBSCS.Name = "rdoBSCS"
        Me.rdoBSCS.Size = New System.Drawing.Size(53, 17)
        Me.rdoBSCS.TabIndex = 1
        Me.rdoBSCS.TabStop = True
        Me.rdoBSCS.Text = "BSCS"
        Me.rdoBSCS.UseVisualStyleBackColor = True
        '
        'rdoBSIT
        '
        Me.rdoBSIT.AutoSize = True
        Me.rdoBSIT.Location = New System.Drawing.Point(7, 47)
        Me.rdoBSIT.Name = "rdoBSIT"
        Me.rdoBSIT.Size = New System.Drawing.Size(49, 17)
        Me.rdoBSIT.TabIndex = 0
        Me.rdoBSIT.TabStop = True
        Me.rdoBSIT.Text = "BSIT"
        Me.rdoBSIT.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.ckMath)
        Me.GroupBox2.Controls.Add(Me.ckSci)
        Me.GroupBox2.Controls.Add(Me.ckFil)
        Me.GroupBox2.Controls.Add(Me.ckEng)
        Me.GroupBox2.Controls.Add(Me.ckCom)
        Me.GroupBox2.Location = New System.Drawing.Point(201, 38)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(209, 219)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Favorite Subject/s"
        '
        'ckMath
        '
        Me.ckMath.AutoSize = True
        Me.ckMath.Location = New System.Drawing.Point(113, 133)
        Me.ckMath.Name = "ckMath"
        Me.ckMath.Size = New System.Drawing.Size(50, 17)
        Me.ckMath.TabIndex = 4
        Me.ckMath.Text = "Math"
        Me.ckMath.UseVisualStyleBackColor = True
        '
        'ckSci
        '
        Me.ckSci.AutoSize = True
        Me.ckSci.Location = New System.Drawing.Point(113, 75)
        Me.ckSci.Name = "ckSci"
        Me.ckSci.Size = New System.Drawing.Size(65, 17)
        Me.ckSci.TabIndex = 3
        Me.ckSci.Text = "Science"
        Me.ckSci.UseVisualStyleBackColor = True
        '
        'ckFil
        '
        Me.ckFil.AutoSize = True
        Me.ckFil.Location = New System.Drawing.Point(16, 161)
        Me.ckFil.Name = "ckFil"
        Me.ckFil.Size = New System.Drawing.Size(58, 17)
        Me.ckFil.TabIndex = 2
        Me.ckFil.Text = "Filipino"
        Me.ckFil.UseVisualStyleBackColor = True
        '
        'ckEng
        '
        Me.ckEng.AutoSize = True
        Me.ckEng.Location = New System.Drawing.Point(16, 105)
        Me.ckEng.Name = "ckEng"
        Me.ckEng.Size = New System.Drawing.Size(60, 17)
        Me.ckEng.TabIndex = 1
        Me.ckEng.Text = "English"
        Me.ckEng.UseVisualStyleBackColor = True
        '
        'ckCom
        '
        Me.ckCom.AutoSize = True
        Me.ckCom.Location = New System.Drawing.Point(16, 47)
        Me.ckCom.Name = "ckCom"
        Me.ckCom.Size = New System.Drawing.Size(71, 17)
        Me.ckCom.TabIndex = 0
        Me.ckCom.Text = "Computer"
        Me.ckCom.UseVisualStyleBackColor = True
        '
        'btnTRB
        '
        Me.btnTRB.Location = New System.Drawing.Point(12, 263)
        Me.btnTRB.Name = "btnTRB"
        Me.btnTRB.Size = New System.Drawing.Size(143, 66)
        Me.btnTRB.TabIndex = 2
        Me.btnTRB.Text = "Test Radio Button"
        Me.btnTRB.UseVisualStyleBackColor = True
        '
        'btnTCB
        '
        Me.btnTCB.Location = New System.Drawing.Point(161, 263)
        Me.btnTCB.Name = "btnTCB"
        Me.btnTCB.Size = New System.Drawing.Size(136, 66)
        Me.btnTCB.TabIndex = 3
        Me.btnTCB.Text = "Test CheckBox"
        Me.btnTCB.UseVisualStyleBackColor = True
        '
        'btnCA
        '
        Me.btnCA.Location = New System.Drawing.Point(304, 263)
        Me.btnCA.Name = "btnCA"
        Me.btnCA.Size = New System.Drawing.Size(106, 66)
        Me.btnCA.TabIndex = 4
        Me.btnCA.Text = "Clear All"
        Me.btnCA.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(422, 338)
        Me.Controls.Add(Me.btnCA)
        Me.Controls.Add(Me.btnTCB)
        Me.Controls.Add(Me.btnTRB)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Radio Button & CheckBox"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoBSIS As System.Windows.Forms.RadioButton
    Friend WithEvents rdoBSCS As System.Windows.Forms.RadioButton
    Friend WithEvents rdoBSIT As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents ckMath As System.Windows.Forms.CheckBox
    Friend WithEvents ckSci As System.Windows.Forms.CheckBox
    Friend WithEvents ckFil As System.Windows.Forms.CheckBox
    Friend WithEvents ckEng As System.Windows.Forms.CheckBox
    Friend WithEvents ckCom As System.Windows.Forms.CheckBox
    Friend WithEvents btnTRB As System.Windows.Forms.Button
    Friend WithEvents btnTCB As System.Windows.Forms.Button
    Friend WithEvents btnCA As System.Windows.Forms.Button

End Class
