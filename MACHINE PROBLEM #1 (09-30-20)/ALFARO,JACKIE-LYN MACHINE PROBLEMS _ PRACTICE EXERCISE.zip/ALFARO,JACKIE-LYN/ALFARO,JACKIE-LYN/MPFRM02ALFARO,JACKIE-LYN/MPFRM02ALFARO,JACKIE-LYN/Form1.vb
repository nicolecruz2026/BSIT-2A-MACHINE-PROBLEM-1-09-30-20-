﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim prelim, midterm, final, result As Double

        prelim = TextBox1.Text
        midterm = TextBox2.Text
        final = TextBox3.Text

        prelim = prelim * 0.25

        midterm = midterm * 0.25

        final = final * 0.5

        result = prelim + midterm + final

        TextBox4.Text = result
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""


    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()
    End Sub
End Class
