﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM02GenesisCoronel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.finalbox = New System.Windows.Forms.TextBox()
        Me.midtermbox = New System.Windows.Forms.TextBox()
        Me.prelimbox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.computebttn = New System.Windows.Forms.Button()
        Me.clearbttn = New System.Windows.Forms.Button()
        Me.closebttn = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.sembox = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.finalbox)
        Me.GroupBox1.Controls.Add(Me.midtermbox)
        Me.GroupBox1.Controls.Add(Me.prelimbox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(172, 194)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Grades Data Entry"
        '
        'finalbox
        '
        Me.finalbox.Location = New System.Drawing.Point(111, 142)
        Me.finalbox.Name = "finalbox"
        Me.finalbox.Size = New System.Drawing.Size(55, 22)
        Me.finalbox.TabIndex = 5
        '
        'midtermbox
        '
        Me.midtermbox.Location = New System.Drawing.Point(111, 89)
        Me.midtermbox.Name = "midtermbox"
        Me.midtermbox.Size = New System.Drawing.Size(55, 22)
        Me.midtermbox.TabIndex = 4
        '
        'prelimbox
        '
        Me.prelimbox.Location = New System.Drawing.Point(111, 37)
        Me.prelimbox.Name = "prelimbox"
        Me.prelimbox.Size = New System.Drawing.Size(55, 22)
        Me.prelimbox.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 147)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Final"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 94)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Midterm"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Prelim"
        '
        'computebttn
        '
        Me.computebttn.Location = New System.Drawing.Point(217, 54)
        Me.computebttn.Name = "computebttn"
        Me.computebttn.Size = New System.Drawing.Size(81, 32)
        Me.computebttn.TabIndex = 1
        Me.computebttn.Text = "Compute"
        Me.computebttn.UseVisualStyleBackColor = True
        '
        'clearbttn
        '
        Me.clearbttn.Location = New System.Drawing.Point(217, 106)
        Me.clearbttn.Name = "clearbttn"
        Me.clearbttn.Size = New System.Drawing.Size(81, 32)
        Me.clearbttn.TabIndex = 2
        Me.clearbttn.Text = "Clear"
        Me.clearbttn.UseVisualStyleBackColor = True
        '
        'closebttn
        '
        Me.closebttn.Location = New System.Drawing.Point(217, 159)
        Me.closebttn.Name = "closebttn"
        Me.closebttn.Size = New System.Drawing.Size(81, 32)
        Me.closebttn.TabIndex = 3
        Me.closebttn.Text = "Close"
        Me.closebttn.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(18, 276)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(115, 17)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Semestral Grade"
        '
        'sembox
        '
        Me.sembox.Enabled = False
        Me.sembox.Location = New System.Drawing.Point(159, 271)
        Me.sembox.Name = "sembox"
        Me.sembox.Size = New System.Drawing.Size(66, 22)
        Me.sembox.TabIndex = 6
        '
        'MPFRM02GenesisCoronel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(310, 375)
        Me.ControlBox = False
        Me.Controls.Add(Me.sembox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.closebttn)
        Me.Controls.Add(Me.clearbttn)
        Me.Controls.Add(Me.computebttn)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MPFRM02GenesisCoronel"
        Me.Text = "Grade Computation"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents finalbox As System.Windows.Forms.TextBox
    Friend WithEvents midtermbox As System.Windows.Forms.TextBox
    Friend WithEvents prelimbox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents computebttn As System.Windows.Forms.Button
    Friend WithEvents clearbttn As System.Windows.Forms.Button
    Friend WithEvents closebttn As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents sembox As System.Windows.Forms.TextBox
End Class
