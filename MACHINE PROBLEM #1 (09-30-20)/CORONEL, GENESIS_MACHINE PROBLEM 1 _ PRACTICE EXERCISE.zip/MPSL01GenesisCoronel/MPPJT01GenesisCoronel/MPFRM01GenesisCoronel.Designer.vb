﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM01GenesisCoronel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.clearbttn = New System.Windows.Forms.Button()
        Me.closebttn = New System.Windows.Forms.Button()
        Me.arg1box = New System.Windows.Forms.TextBox()
        Me.arg2box = New System.Windows.Forms.TextBox()
        Me.resbox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.divintbttn = New System.Windows.Forms.Button()
        Me.modbttn = New System.Windows.Forms.Button()
        Me.divbttn = New System.Windows.Forms.Button()
        Me.mulbttn = New System.Windows.Forms.Button()
        Me.minbttn = New System.Windows.Forms.Button()
        Me.addbttn = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(48, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Argument 1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(48, 71)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Argument 2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(48, 122)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Result"
        '
        'clearbttn
        '
        Me.clearbttn.Location = New System.Drawing.Point(292, 26)
        Me.clearbttn.Name = "clearbttn"
        Me.clearbttn.Size = New System.Drawing.Size(65, 56)
        Me.clearbttn.TabIndex = 3
        Me.clearbttn.Text = "Clear"
        Me.clearbttn.UseVisualStyleBackColor = True
        '
        'closebttn
        '
        Me.closebttn.Location = New System.Drawing.Point(292, 83)
        Me.closebttn.Name = "closebttn"
        Me.closebttn.Size = New System.Drawing.Size(65, 56)
        Me.closebttn.TabIndex = 4
        Me.closebttn.Text = "Close"
        Me.closebttn.UseVisualStyleBackColor = True
        '
        'arg1box
        '
        Me.arg1box.Location = New System.Drawing.Point(182, 26)
        Me.arg1box.Name = "arg1box"
        Me.arg1box.Size = New System.Drawing.Size(48, 22)
        Me.arg1box.TabIndex = 5
        '
        'arg2box
        '
        Me.arg2box.Location = New System.Drawing.Point(182, 71)
        Me.arg2box.Name = "arg2box"
        Me.arg2box.Size = New System.Drawing.Size(48, 22)
        Me.arg2box.TabIndex = 6
        '
        'resbox
        '
        Me.resbox.Location = New System.Drawing.Point(182, 117)
        Me.resbox.Name = "resbox"
        Me.resbox.Size = New System.Drawing.Size(48, 22)
        Me.resbox.TabIndex = 7
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.divintbttn)
        Me.GroupBox1.Controls.Add(Me.modbttn)
        Me.GroupBox1.Controls.Add(Me.divbttn)
        Me.GroupBox1.Controls.Add(Me.mulbttn)
        Me.GroupBox1.Controls.Add(Me.minbttn)
        Me.GroupBox1.Controls.Add(Me.addbttn)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 184)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(366, 100)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Operations"
        '
        'divintbttn
        '
        Me.divintbttn.Font = New System.Drawing.Font("Calibri", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.divintbttn.Location = New System.Drawing.Point(306, 37)
        Me.divintbttn.Name = "divintbttn"
        Me.divintbttn.Size = New System.Drawing.Size(54, 57)
        Me.divintbttn.TabIndex = 5
        Me.divintbttn.Text = "\"
        Me.divintbttn.UseVisualStyleBackColor = True
        '
        'modbttn
        '
        Me.modbttn.Font = New System.Drawing.Font("Calibri", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.modbttn.Location = New System.Drawing.Point(246, 37)
        Me.modbttn.Name = "modbttn"
        Me.modbttn.Size = New System.Drawing.Size(54, 57)
        Me.modbttn.TabIndex = 4
        Me.modbttn.Text = "MOD"
        Me.modbttn.UseVisualStyleBackColor = True
        '
        'divbttn
        '
        Me.divbttn.Font = New System.Drawing.Font("Calibri", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.divbttn.Location = New System.Drawing.Point(186, 37)
        Me.divbttn.Name = "divbttn"
        Me.divbttn.Size = New System.Drawing.Size(54, 57)
        Me.divbttn.TabIndex = 3
        Me.divbttn.Text = "/"
        Me.divbttn.UseVisualStyleBackColor = True
        '
        'mulbttn
        '
        Me.mulbttn.Font = New System.Drawing.Font("Calibri", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mulbttn.Location = New System.Drawing.Point(126, 37)
        Me.mulbttn.Name = "mulbttn"
        Me.mulbttn.Size = New System.Drawing.Size(54, 57)
        Me.mulbttn.TabIndex = 2
        Me.mulbttn.Text = "*"
        Me.mulbttn.UseVisualStyleBackColor = True
        '
        'minbttn
        '
        Me.minbttn.Font = New System.Drawing.Font("Calibri", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minbttn.Location = New System.Drawing.Point(66, 37)
        Me.minbttn.Name = "minbttn"
        Me.minbttn.Size = New System.Drawing.Size(54, 57)
        Me.minbttn.TabIndex = 1
        Me.minbttn.Text = "-"
        Me.minbttn.UseVisualStyleBackColor = True
        '
        'addbttn
        '
        Me.addbttn.Font = New System.Drawing.Font("Calibri", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addbttn.Location = New System.Drawing.Point(6, 37)
        Me.addbttn.Name = "addbttn"
        Me.addbttn.Size = New System.Drawing.Size(54, 57)
        Me.addbttn.TabIndex = 0
        Me.addbttn.Text = "+"
        Me.addbttn.UseVisualStyleBackColor = True
        '
        'MPFRM01GenesisCoronel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(410, 321)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.resbox)
        Me.Controls.Add(Me.arg2box)
        Me.Controls.Add(Me.arg1box)
        Me.Controls.Add(Me.closebttn)
        Me.Controls.Add(Me.clearbttn)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "MPFRM01GenesisCoronel"
        Me.Text = "VB.NET Mathematical Operators"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents clearbttn As System.Windows.Forms.Button
    Friend WithEvents closebttn As System.Windows.Forms.Button
    Friend WithEvents arg1box As System.Windows.Forms.TextBox
    Friend WithEvents arg2box As System.Windows.Forms.TextBox
    Friend WithEvents resbox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents divintbttn As System.Windows.Forms.Button
    Friend WithEvents modbttn As System.Windows.Forms.Button
    Friend WithEvents divbttn As System.Windows.Forms.Button
    Friend WithEvents mulbttn As System.Windows.Forms.Button
    Friend WithEvents minbttn As System.Windows.Forms.Button
    Friend WithEvents addbttn As System.Windows.Forms.Button

End Class
