﻿Public Class RadioButtonAndCheckBox

    Private Sub btnTestRdoBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestRdoBtn.Click
        If rdoBSIT.Checked = True Then
            MessageBox.Show("Your course is: " + rdoBSIT.Text, "RadioButton")
        ElseIf rdoBSCS.Checked = True Then
            MessageBox.Show("Your course is: " + rdoBSCS.Text, "RadioButton")
        ElseIf rdoBSIS.Checked = True Then
            MessageBox.Show("Your course is: " + rdoBSIS.Text, "RadioButton")
        Else
            MessageBox.Show("No course selected...", "Radio Button")
        End If
    End Sub

    Private Sub btnTestChkBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestChkBox.Click

        Dim Subj As String

        If chkCom.Checked Then
            Subj = Subj + chkCom.Text + vbNewLine
        End If
        If chkEng.Checked Then
            Subj = Subj + chkEng.Text + vbNewLine
        End If
        If chkFil.Checked Then
            Subj = Subj + chkFil.Text + vbNewLine
        End If
        If chkSci.Checked Then
            Subj = Subj + chkSci.Text + vbNewLine
        End If
        If chkmat.Checked Then
            Subj = Subj + chkmat.Text + vbNewLine
        End If
        MessageBox.Show("Your favorite subject/s is/are:" + vbNewLine + Subj, "Check Box")
    End Sub

    Private Sub btnClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click
        'To clear radio buttons
        rdoBSIT.Checked = False
        rdoBSCS.Checked = False
        rdoBSIS.Checked = False
        'To clear check boxes
        chkFil.Checked = False
        chkCom.Checked = False
        chkSci.Checked = False
        chkEng.Checked = False
        chkmat.Checked = False
    End Sub
End Class