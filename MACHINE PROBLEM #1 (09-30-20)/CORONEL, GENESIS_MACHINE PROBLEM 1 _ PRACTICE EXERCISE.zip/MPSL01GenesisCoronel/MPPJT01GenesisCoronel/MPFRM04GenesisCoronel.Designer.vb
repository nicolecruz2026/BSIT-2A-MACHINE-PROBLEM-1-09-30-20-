﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM04GenesisCoronel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.equalbox = New System.Windows.Forms.TextBox()
        Me.powerbox = New System.Windows.Forms.TextBox()
        Me.basebox = New System.Windows.Forms.TextBox()
        Me.equalbttn = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.diambox = New System.Windows.Forms.TextBox()
        Me.areabox = New System.Windows.Forms.TextBox()
        Me.diambttn = New System.Windows.Forms.Button()
        Me.circumbttn = New System.Windows.Forms.Button()
        Me.areabttn = New System.Windows.Forms.Button()
        Me.circumbox = New System.Windows.Forms.TextBox()
        Me.radiusbox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.clearallbttn = New System.Windows.Forms.Button()
        Me.exitbttn = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.equalbox)
        Me.GroupBox1.Controls.Add(Me.powerbox)
        Me.GroupBox1.Controls.Add(Me.basebox)
        Me.GroupBox1.Controls.Add(Me.equalbttn)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 26)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(166, 195)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Exponent"
        '
        'equalbox
        '
        Me.equalbox.Location = New System.Drawing.Point(104, 131)
        Me.equalbox.Name = "equalbox"
        Me.equalbox.Size = New System.Drawing.Size(56, 22)
        Me.equalbox.TabIndex = 3
        '
        'powerbox
        '
        Me.powerbox.Location = New System.Drawing.Point(104, 82)
        Me.powerbox.Name = "powerbox"
        Me.powerbox.Size = New System.Drawing.Size(56, 22)
        Me.powerbox.TabIndex = 2
        '
        'basebox
        '
        Me.basebox.Location = New System.Drawing.Point(104, 38)
        Me.basebox.Name = "basebox"
        Me.basebox.Size = New System.Drawing.Size(56, 22)
        Me.basebox.TabIndex = 1
        '
        'equalbttn
        '
        Me.equalbttn.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.equalbttn.Location = New System.Drawing.Point(6, 131)
        Me.equalbttn.Name = "equalbttn"
        Me.equalbttn.Size = New System.Drawing.Size(40, 35)
        Me.equalbttn.TabIndex = 1
        Me.equalbttn.Text = "="
        Me.equalbttn.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Power"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Base"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.diambox)
        Me.GroupBox2.Controls.Add(Me.areabox)
        Me.GroupBox2.Controls.Add(Me.diambttn)
        Me.GroupBox2.Controls.Add(Me.circumbttn)
        Me.GroupBox2.Controls.Add(Me.areabttn)
        Me.GroupBox2.Controls.Add(Me.circumbox)
        Me.GroupBox2.Controls.Add(Me.radiusbox)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(206, 26)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(194, 195)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Circle"
        '
        'diambox
        '
        Me.diambox.Location = New System.Drawing.Point(132, 166)
        Me.diambox.Multiline = True
        Me.diambox.Name = "diambox"
        Me.diambox.Size = New System.Drawing.Size(56, 23)
        Me.diambox.TabIndex = 9
        '
        'areabox
        '
        Me.areabox.Location = New System.Drawing.Point(132, 95)
        Me.areabox.Multiline = True
        Me.areabox.Name = "areabox"
        Me.areabox.Size = New System.Drawing.Size(56, 23)
        Me.areabox.TabIndex = 8
        '
        'diambttn
        '
        Me.diambttn.Location = New System.Drawing.Point(9, 166)
        Me.diambttn.Name = "diambttn"
        Me.diambttn.Size = New System.Drawing.Size(117, 23)
        Me.diambttn.TabIndex = 7
        Me.diambttn.Text = "Diameter"
        Me.diambttn.UseVisualStyleBackColor = True
        '
        'circumbttn
        '
        Me.circumbttn.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.circumbttn.Location = New System.Drawing.Point(9, 131)
        Me.circumbttn.Name = "circumbttn"
        Me.circumbttn.Size = New System.Drawing.Size(117, 23)
        Me.circumbttn.TabIndex = 6
        Me.circumbttn.Text = "Circumference"
        Me.circumbttn.UseVisualStyleBackColor = True
        '
        'areabttn
        '
        Me.areabttn.Location = New System.Drawing.Point(9, 95)
        Me.areabttn.Name = "areabttn"
        Me.areabttn.Size = New System.Drawing.Size(117, 23)
        Me.areabttn.TabIndex = 5
        Me.areabttn.Text = "Area"
        Me.areabttn.UseVisualStyleBackColor = True
        '
        'circumbox
        '
        Me.circumbox.Location = New System.Drawing.Point(132, 132)
        Me.circumbox.Multiline = True
        Me.circumbox.Name = "circumbox"
        Me.circumbox.Size = New System.Drawing.Size(56, 23)
        Me.circumbox.TabIndex = 3
        '
        'radiusbox
        '
        Me.radiusbox.Location = New System.Drawing.Point(132, 38)
        Me.radiusbox.Name = "radiusbox"
        Me.radiusbox.Size = New System.Drawing.Size(56, 22)
        Me.radiusbox.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(41, 43)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 17)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Radius"
        '
        'clearallbttn
        '
        Me.clearallbttn.Location = New System.Drawing.Point(12, 241)
        Me.clearallbttn.Name = "clearallbttn"
        Me.clearallbttn.Size = New System.Drawing.Size(86, 37)
        Me.clearallbttn.TabIndex = 5
        Me.clearallbttn.Text = "Clear All"
        Me.clearallbttn.UseVisualStyleBackColor = True
        '
        'exitbttn
        '
        Me.exitbttn.Location = New System.Drawing.Point(104, 241)
        Me.exitbttn.Name = "exitbttn"
        Me.exitbttn.Size = New System.Drawing.Size(86, 37)
        Me.exitbttn.TabIndex = 6
        Me.exitbttn.Text = "Exit"
        Me.exitbttn.UseVisualStyleBackColor = True
        '
        'MPFRM04GenesisCoronel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(415, 295)
        Me.Controls.Add(Me.exitbttn)
        Me.Controls.Add(Me.clearallbttn)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "MPFRM04GenesisCoronel"
        Me.Text = "Usage of Caret (^) Symbol"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents equalbox As System.Windows.Forms.TextBox
    Friend WithEvents powerbox As System.Windows.Forms.TextBox
    Friend WithEvents basebox As System.Windows.Forms.TextBox
    Friend WithEvents equalbttn As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents diambox As System.Windows.Forms.TextBox
    Friend WithEvents areabox As System.Windows.Forms.TextBox
    Friend WithEvents diambttn As System.Windows.Forms.Button
    Friend WithEvents circumbttn As System.Windows.Forms.Button
    Friend WithEvents areabttn As System.Windows.Forms.Button
    Friend WithEvents circumbox As System.Windows.Forms.TextBox
    Friend WithEvents radiusbox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents clearallbttn As System.Windows.Forms.Button
    Friend WithEvents exitbttn As System.Windows.Forms.Button
End Class
