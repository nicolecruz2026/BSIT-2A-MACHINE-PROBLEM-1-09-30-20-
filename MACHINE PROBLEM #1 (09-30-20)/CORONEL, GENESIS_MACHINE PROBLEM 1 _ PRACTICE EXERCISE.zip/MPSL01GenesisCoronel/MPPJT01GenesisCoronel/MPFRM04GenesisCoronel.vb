﻿Public Class MPFRM04GenesisCoronel
    Private Sub equalbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles equalbttn.Click

        Dim base, power, equal As Double

        base = basebox.Text
        power = powerbox.Text

        equal = (base) ^ power
        equalbox.Text = equal

    End Sub

    Private Sub areabttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles areabttn.Click

        Dim π As Double = 3.1416
        Dim radius, area As Double

        radius = radiusbox.Text

        area = π * (radius) ^ 2
        areabox.Text = Format(area, "####.00")

    End Sub

    Private Sub circumbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles circumbttn.Click

        Dim π As Double = 3.1416
        Dim radius, circum As Double

        radius = radiusbox.Text

        circum = 2 * π * radius
        circumbox.Text = Format(circum, "####.00")


    End Sub

    Private Sub diambttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles diambttn.Click

        Dim radius, diam As Double

        radius = radiusbox.Text

        diam = 2 * radius
        diambox.Text = Format(diam, "####.00")

    End Sub

    Private Sub clearallbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clearallbttn.Click

        basebox.Clear()
        powerbox.Clear()
        equalbox.Clear()
        radiusbox.Clear()
        areabox.Clear()
        circumbox.Clear()
        diambox.Clear()

    End Sub

    Private Sub exitbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitbttn.Click

        Close()

    End Sub
End Class