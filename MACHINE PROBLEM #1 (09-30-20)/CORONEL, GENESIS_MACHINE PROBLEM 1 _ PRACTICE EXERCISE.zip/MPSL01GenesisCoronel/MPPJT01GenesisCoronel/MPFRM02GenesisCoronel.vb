﻿Public Class MPFRM02GenesisCoronel
    Private Sub computebttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles computebttn.Click

        Dim prelim, midterm, final, semgrade As Double

        prelim = prelimbox.Text
        midterm = midtermbox.Text
        final = finalbox.Text

        semgrade = (((prelim + midterm) / 2 + final) / 2)
        sembox.Text = semgrade

    End Sub

    Private Sub clearbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clearbttn.Click

        prelimbox.Clear()
        midtermbox.Clear()
        finalbox.Clear()
        sembox.Clear()

    End Sub

    Private Sub closebttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closebttn.Click

        Close()

    End Sub

    Private Sub computebttn_ClientSizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles computebttn.ClientSizeChanged

    End Sub
End Class