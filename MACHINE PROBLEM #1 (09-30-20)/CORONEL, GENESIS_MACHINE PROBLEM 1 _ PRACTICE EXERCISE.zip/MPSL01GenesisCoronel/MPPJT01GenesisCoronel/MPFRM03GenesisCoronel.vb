﻿Public Class MPFRM03GenesisCoronel

    Private Sub calculatebttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles calculatebttn.Click

        Dim prodamount, quantity, subtotal, discount, netamount As Double

        prodamount = prodamountbox.Text
        quantity = quantitybox.Text

        subtotal = prodamount * quantity
        subtotalbox.Text = subtotal

        discount = subtotal * 0.2
        discountbox.Text = discount

        netamount = subtotal - discount
        netamountbox.Text = netamount

    End Sub

    Private Sub clearbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clearbttn.Click

        prodamountbox.Clear()
        quantitybox.Clear()
        subtotalbox.Clear()
        discountbox.Clear()
        netamountbox.Clear()

    End Sub

    Private Sub closebttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closebttn.Click

        Close()

    End Sub
End Class
