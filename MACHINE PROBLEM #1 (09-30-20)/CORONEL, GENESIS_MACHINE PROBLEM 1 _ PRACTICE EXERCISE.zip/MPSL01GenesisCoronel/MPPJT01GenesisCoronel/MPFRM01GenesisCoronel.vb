﻿Public Class MPFRM01GenesisCoronel

    Private Sub addbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addbttn.Click

        Dim num1, num2, result As Double

        num1 = arg1box.Text
        num2 = arg2box.Text

        result = num1 + num2

        resbox.Text = result

    End Sub

    Private Sub minbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles minbttn.Click

        Dim num1, num2, result As Double

        num1 = arg1box.Text
        num2 = arg2box.Text

        result = num1 - num2

        resbox.Text = result

    End Sub

    Private Sub mulbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mulbttn.Click

        Dim num1, num2, result As Double

        num1 = arg1box.Text
        num2 = arg2box.Text

        result = num1 * num2

        resbox.Text = result

    End Sub

    Private Sub divbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles divbttn.Click

        Dim num1, num2, result As Double

        num1 = arg1box.Text
        num2 = arg2box.Text

        result = num1 / num2

        resbox.Text = result

    End Sub

    Private Sub modbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles modbttn.Click

        Dim num1, num2, result As Double

        num1 = arg1box.Text
        num2 = arg2box.Text

        result = num1 Mod num2

        resbox.Text = result

    End Sub

    Private Sub divintbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles divintbttn.Click

        Dim num1, num2, result As Double

        num1 = arg1box.Text
        num2 = arg2box.Text

        result = num1 \ num2

        resbox.Text = result

    End Sub

    Private Sub clearbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clearbttn.Click

        arg1box.Clear()
        arg2box.Clear()
        resbox.Clear()

    End Sub

    Private Sub closebttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closebttn.Click

        Close()

    End Sub
End Class
