﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM03GenesisCoronel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.prodamountbox = New System.Windows.Forms.TextBox()
        Me.quantitybox = New System.Windows.Forms.TextBox()
        Me.subtotalbox = New System.Windows.Forms.TextBox()
        Me.discountbox = New System.Windows.Forms.TextBox()
        Me.netamountbox = New System.Windows.Forms.TextBox()
        Me.calculatebttn = New System.Windows.Forms.Button()
        Me.clearbttn = New System.Windows.Forms.Button()
        Me.closebttn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Product Amount"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Quantity"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(69, 151)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Sub-Total"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(69, 206)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(115, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Discount Amount"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(30, 273)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(82, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Net Amount"
        '
        'prodamountbox
        '
        Me.prodamountbox.Location = New System.Drawing.Point(190, 41)
        Me.prodamountbox.Name = "prodamountbox"
        Me.prodamountbox.Size = New System.Drawing.Size(66, 22)
        Me.prodamountbox.TabIndex = 5
        '
        'quantitybox
        '
        Me.quantitybox.Location = New System.Drawing.Point(190, 92)
        Me.quantitybox.Name = "quantitybox"
        Me.quantitybox.Size = New System.Drawing.Size(66, 22)
        Me.quantitybox.TabIndex = 6
        '
        'subtotalbox
        '
        Me.subtotalbox.Location = New System.Drawing.Point(233, 146)
        Me.subtotalbox.Name = "subtotalbox"
        Me.subtotalbox.Size = New System.Drawing.Size(66, 22)
        Me.subtotalbox.TabIndex = 7
        '
        'discountbox
        '
        Me.discountbox.Location = New System.Drawing.Point(233, 201)
        Me.discountbox.Name = "discountbox"
        Me.discountbox.Size = New System.Drawing.Size(66, 22)
        Me.discountbox.TabIndex = 8
        '
        'netamountbox
        '
        Me.netamountbox.Location = New System.Drawing.Point(190, 268)
        Me.netamountbox.Name = "netamountbox"
        Me.netamountbox.Size = New System.Drawing.Size(66, 22)
        Me.netamountbox.TabIndex = 9
        '
        'calculatebttn
        '
        Me.calculatebttn.Location = New System.Drawing.Point(33, 359)
        Me.calculatebttn.Name = "calculatebttn"
        Me.calculatebttn.Size = New System.Drawing.Size(88, 35)
        Me.calculatebttn.TabIndex = 10
        Me.calculatebttn.Text = "Calculate"
        Me.calculatebttn.UseVisualStyleBackColor = True
        '
        'clearbttn
        '
        Me.clearbttn.Location = New System.Drawing.Point(127, 359)
        Me.clearbttn.Name = "clearbttn"
        Me.clearbttn.Size = New System.Drawing.Size(88, 35)
        Me.clearbttn.TabIndex = 11
        Me.clearbttn.Text = "Clear"
        Me.clearbttn.UseVisualStyleBackColor = True
        '
        'closebttn
        '
        Me.closebttn.Location = New System.Drawing.Point(221, 359)
        Me.closebttn.Name = "closebttn"
        Me.closebttn.Size = New System.Drawing.Size(86, 35)
        Me.closebttn.TabIndex = 12
        Me.closebttn.Text = "Close"
        Me.closebttn.UseVisualStyleBackColor = True
        '
        'MPFRM03GenesisCoronel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(347, 420)
        Me.Controls.Add(Me.closebttn)
        Me.Controls.Add(Me.clearbttn)
        Me.Controls.Add(Me.calculatebttn)
        Me.Controls.Add(Me.netamountbox)
        Me.Controls.Add(Me.discountbox)
        Me.Controls.Add(Me.subtotalbox)
        Me.Controls.Add(Me.quantitybox)
        Me.Controls.Add(Me.prodamountbox)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "MPFRM03GenesisCoronel"
        Me.Text = "Computing Net Amount"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents prodamountbox As System.Windows.Forms.TextBox
    Friend WithEvents quantitybox As System.Windows.Forms.TextBox
    Friend WithEvents subtotalbox As System.Windows.Forms.TextBox
    Friend WithEvents discountbox As System.Windows.Forms.TextBox
    Friend WithEvents netamountbox As System.Windows.Forms.TextBox
    Friend WithEvents calculatebttn As System.Windows.Forms.Button
    Friend WithEvents clearbttn As System.Windows.Forms.Button
    Friend WithEvents closebttn As System.Windows.Forms.Button
End Class
