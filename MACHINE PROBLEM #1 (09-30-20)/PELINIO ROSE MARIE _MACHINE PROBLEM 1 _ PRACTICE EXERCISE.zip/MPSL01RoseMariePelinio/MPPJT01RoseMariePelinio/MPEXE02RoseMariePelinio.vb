﻿Public Class frmColor


    Private Sub frmColor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblBlue_MouseMove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblBlue_MouseMove.Click
        Me.BackColor = Color.Blue
    End Sub

    Private Sub lblGreen_MouseMove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblGreen_MouseMove.Click
        Me.BackColor = Color.Green
    End Sub

    Private Sub lblYellow_MouseMove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblYellow_MouseMove.Click
        Me.BackColor = Color.Yellow
    End Sub

    Private Sub lblRed_MouseMove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblRed_MouseMove.Click
        Me.BackColor = Color.Red
    End Sub

    Private Sub lblWhite_MouseMove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblWhite_MouseMove.Click
        Me.BackColor = Color.White
    End Sub
End Class