﻿Public Class frmDisplay

    Private Sub frmDisplay_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnClick_Display_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClick_Display.Click
        txtDisplay.Text = " Welcome to Visual BASIC.NET Programming "
    End Sub
End Class