﻿Public Class MPFRM01RoseMariePelinio

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim ass1, ass2, sum As Integer

        ass1 = TextBox1.Text
        ass2 = TextBox2.Text

        sum = ass1 + ass2
        TextBox3.Text = sum

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim ass1, ass2, difference As Integer

        ass1 = TextBox1.Text
        ass2 = TextBox2.Text

        difference = ass1 - ass2
        TextBox3.Text = difference
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim ass1, ass2, product As Integer

        ass1 = TextBox1.Text
        ass2 = TextBox2.Text

        product = ass1 * ass2
        TextBox3.Text = product
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim ass1, ass2, quotient As Integer

        ass1 = TextBox1.Text
        ass2 = TextBox2.Text

        quotient = ass1 / ass2
        TextBox3.Text = quotient
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim ass1, ass2, dom As Integer

        ass1 = TextBox1.Text
        ass2 = TextBox2.Text

        dom = ass1 Mod ass2
        TextBox3.Text = dom
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim ass1, ass2, percent As Integer

        ass1 = TextBox1.Text
        ass2 = TextBox2.Text

        percent = ass1 \ ass2
        TextBox3.Text = percent
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Close()
    End Sub

End Class
