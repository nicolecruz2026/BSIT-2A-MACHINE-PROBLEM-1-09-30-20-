﻿Public Class MPFRM03RoseMariePelinio


    Private Sub MPFRM03RoseMariePelinio_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim product, quantity, subtotal, discount, netamount As Integer

        product = TextBox1.Text
        quantity = TextBox2.Text

        subtotal = product * quantity
        TextBox3.Text = subtotal

        discount = subtotal * 0.2
        TextBox4.Text = discount

        netamount = subtotal - discount
        TextBox5.Text = netamount


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""


    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()

    End Sub
End Class