﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmColor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblBlue_MouseMove = New System.Windows.Forms.Label()
        Me.lblGreen_MouseMove = New System.Windows.Forms.Label()
        Me.lblYellow_MouseMove = New System.Windows.Forms.Label()
        Me.lblRed_MouseMove = New System.Windows.Forms.Label()
        Me.lblWhite_MouseMove = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblBlue_MouseMove
        '
        Me.lblBlue_MouseMove.AutoSize = True
        Me.lblBlue_MouseMove.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBlue_MouseMove.Location = New System.Drawing.Point(45, 34)
        Me.lblBlue_MouseMove.Name = "lblBlue_MouseMove"
        Me.lblBlue_MouseMove.Size = New System.Drawing.Size(41, 20)
        Me.lblBlue_MouseMove.TabIndex = 0
        Me.lblBlue_MouseMove.Text = "Blue"
        '
        'lblGreen_MouseMove
        '
        Me.lblGreen_MouseMove.AutoSize = True
        Me.lblGreen_MouseMove.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGreen_MouseMove.Location = New System.Drawing.Point(45, 83)
        Me.lblGreen_MouseMove.Name = "lblGreen_MouseMove"
        Me.lblGreen_MouseMove.Size = New System.Drawing.Size(54, 20)
        Me.lblGreen_MouseMove.TabIndex = 1
        Me.lblGreen_MouseMove.Text = "Green"
        '
        'lblYellow_MouseMove
        '
        Me.lblYellow_MouseMove.AutoSize = True
        Me.lblYellow_MouseMove.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYellow_MouseMove.Location = New System.Drawing.Point(45, 124)
        Me.lblYellow_MouseMove.Name = "lblYellow_MouseMove"
        Me.lblYellow_MouseMove.Size = New System.Drawing.Size(55, 20)
        Me.lblYellow_MouseMove.TabIndex = 2
        Me.lblYellow_MouseMove.Text = "Yellow"
        '
        'lblRed_MouseMove
        '
        Me.lblRed_MouseMove.AutoSize = True
        Me.lblRed_MouseMove.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRed_MouseMove.Location = New System.Drawing.Point(45, 169)
        Me.lblRed_MouseMove.Name = "lblRed_MouseMove"
        Me.lblRed_MouseMove.Size = New System.Drawing.Size(39, 20)
        Me.lblRed_MouseMove.TabIndex = 3
        Me.lblRed_MouseMove.Text = "Red"
        '
        'lblWhite_MouseMove
        '
        Me.lblWhite_MouseMove.AutoSize = True
        Me.lblWhite_MouseMove.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWhite_MouseMove.Location = New System.Drawing.Point(45, 212)
        Me.lblWhite_MouseMove.Name = "lblWhite_MouseMove"
        Me.lblWhite_MouseMove.Size = New System.Drawing.Size(50, 20)
        Me.lblWhite_MouseMove.TabIndex = 4
        Me.lblWhite_MouseMove.Text = "White"
        '
        'frmColor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(238, 261)
        Me.Controls.Add(Me.lblWhite_MouseMove)
        Me.Controls.Add(Me.lblRed_MouseMove)
        Me.Controls.Add(Me.lblYellow_MouseMove)
        Me.Controls.Add(Me.lblGreen_MouseMove)
        Me.Controls.Add(Me.lblBlue_MouseMove)
        Me.Name = "frmColor"
        Me.Text = "Color Function"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblBlue_MouseMove As System.Windows.Forms.Label
    Friend WithEvents lblGreen_MouseMove As System.Windows.Forms.Label
    Friend WithEvents lblYellow_MouseMove As System.Windows.Forms.Label
    Friend WithEvents lblRed_MouseMove As System.Windows.Forms.Label
    Friend WithEvents lblWhite_MouseMove As System.Windows.Forms.Label
End Class
